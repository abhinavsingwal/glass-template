# Glassmorphism Creative Cloud App Redesign

A Pen created on CodePen.io. Original URL: [https://codepen.io/TurkAysenur/pen/ZEpxeYm](https://codepen.io/TurkAysenur/pen/ZEpxeYm).

Inspired by Mikołaj Gałęziowski
"https://dribbble.com/shots/14831798-Glassmorphism-Big-Sur-Creative-Cloud-App-Redesign"